---
title: friends
date: 2019-07-19 16:42:10
type: "friends"
layout: "friends"
---

**感谢所有支持和打赏过我的人，希望今后也能和大家一起学习进步。**
> \*子汉，\*玎乐，\*华翔，\*九