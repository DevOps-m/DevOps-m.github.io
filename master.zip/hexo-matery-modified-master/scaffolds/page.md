---
title: {{ title }}
date: {{ date }}
type: {{ title }}
layout: {{ title }}
---
