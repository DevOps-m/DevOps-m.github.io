# hexo-matery-modified
My personal modified hexo matery theme with some bugs fixed, modified from [hexo-theme-matery](https://github.com/blinkfox/hexo-theme-matery)

# Demo
[https://godweiyang.com](https://godweiyang.com)

# Usage
[https://godweiyang.com/2018/04/13/hexo-blog/](https://godweiyang.com/2018/04/13/hexo-blog/)